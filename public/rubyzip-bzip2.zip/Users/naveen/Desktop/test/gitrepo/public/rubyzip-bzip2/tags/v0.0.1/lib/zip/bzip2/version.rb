# frozen_string_literal: true

module Zip
  module Bzip2
    VERSION = '0.0.1'
  end
end
