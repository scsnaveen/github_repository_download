class User < ActiveRecord::Base
  has_friendship
end
