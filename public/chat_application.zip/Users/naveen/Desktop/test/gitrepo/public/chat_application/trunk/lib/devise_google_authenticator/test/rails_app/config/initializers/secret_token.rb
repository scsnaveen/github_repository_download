# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RailsApp::Application.config.secret_token = '4ca65f35554ff587273162868e8912766dbfad18a51a3674df31e4cad80b0b6d51c8d66500c81b838ebbf279309ec9c56097510f7111c9d28c5266a9d0af769d'
