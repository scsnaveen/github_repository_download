module HasFriendship
  VERSION = "1.1.8"
end
