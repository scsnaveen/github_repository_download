class Post < PARENT_MODEL_CLASS
end
