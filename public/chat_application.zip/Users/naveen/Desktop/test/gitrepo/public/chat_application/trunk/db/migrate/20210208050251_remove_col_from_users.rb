class RemoveColFromUsers < ActiveRecord::Migration[6.0]
	def change
		remove_column :users, :role_id, :string
	end
end
