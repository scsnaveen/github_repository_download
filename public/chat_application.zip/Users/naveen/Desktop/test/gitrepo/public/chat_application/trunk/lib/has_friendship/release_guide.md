# Release guide

1. Bump the version in `version.rb`
2. Update `CHANGELOG.md`
3. Run `bundle install` (needed?)
4. Commit with the version number
5. Run `bundle exec rake release`

