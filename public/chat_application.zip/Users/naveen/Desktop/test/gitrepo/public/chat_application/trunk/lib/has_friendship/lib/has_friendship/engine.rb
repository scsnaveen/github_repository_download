module HasFriendship
  class Engine < ::Rails::Engine
    # isolate_namespace HasFriendship
  end
end
