class Unfriendable < ActiveRecord::Base
end
