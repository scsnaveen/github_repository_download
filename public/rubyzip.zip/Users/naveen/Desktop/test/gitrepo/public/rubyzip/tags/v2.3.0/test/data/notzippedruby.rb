#!/usr/bin/env ruby

class NotZippedRuby
  def return_true
    true
  end
end
