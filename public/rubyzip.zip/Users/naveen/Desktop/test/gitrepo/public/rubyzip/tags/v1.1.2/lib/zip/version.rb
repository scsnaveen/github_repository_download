module Zip
  VERSION = '1.1.2'
end
