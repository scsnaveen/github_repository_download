module Zip
  VERSION = '1.0.0.beta1'
end