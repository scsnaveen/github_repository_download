#!/usr/bin/env ruby
require 'coveralls'
Coveralls.wear!

$VERBOSE = true

require 'ioextrastest'
require 'ziptest'
require 'zipfilesystemtest'
