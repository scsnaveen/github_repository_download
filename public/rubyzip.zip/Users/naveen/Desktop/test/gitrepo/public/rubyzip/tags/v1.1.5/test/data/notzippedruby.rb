#!/usr/bin/env ruby

class NotZippedRuby
  def returnTrue
    true
  end
end
